import axios from 'axios'

async function makeOneGetRequest(n) {
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`For request ${n}, server replied: `, response.data);
}

async function makeThreeSerialRequests(): Promise<void> {
    await makeOneGetRequest(1);
    console.log('Heard back from first request')
    await makeOneGetRequest(2);
    console.log('Heard back from second request')
    await makeOneGetRequest(3);
    console.log('Heard back from third request')
}

makeThreeSerialRequests();
