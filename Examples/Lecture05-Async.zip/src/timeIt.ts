export default async function timeIt (thunk: () => Promise<any>) {
    const t0 = performance.now();
    await thunk();    
    const t1 = performance.now()
    console.log(`Elapsed time: ${t1 - t0} milliseconds`)
    
}

