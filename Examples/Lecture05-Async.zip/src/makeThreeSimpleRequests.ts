import makeOneGetRequest from './makeOneGetRequest'

async function makeThreeSimpleRequests() {
    makeOneGetRequest(1);
    makeOneGetRequest(2);
    makeOneGetRequest(3);
    console.log("Three requests made")
}

makeThreeSimpleRequests()