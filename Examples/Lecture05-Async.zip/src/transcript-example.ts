import axios from 'axios';
import { promises as fsPromises } from 'fs';

async function promiseForTranscript(studentID: number) {
    const response = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
    await fsPromises.writeFile(`transcript-${response.data.student.studentID}.json`,
        JSON.stringify(response.data))
}


async function runClientAsync(studentIDs:number[]) {
    console.log(`Making requests for ${studentIDs}`); 
    const promisesForTranscripts = studentIDs.map(studentID => promiseForTranscript(studentID))     
    console.log('Requests sent!');
    await Promise.all(promisesForTranscripts);
    const stats = await Promise.all(studentIDs.map(studentID => fsPromises.stat(`transcript-${studentID}.json`)));
    const totalSize = stats.reduce((runningTotal, val) => runningTotal + val.size, 0);
    console.log(`Finished calculating size: ${totalSize}`);
    console.log('Done');
  }

  runClientAsync([1,2,3])
  