import axios from 'axios';
import timeIt from './timeIt';

export default async function makeOneGetRequest(requestNumber:number) {
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`For request ${requestNumber}, server replied: `, response.data);
}

// export default async function makeOneGetRequest(requestNumber:number) {
//     const response = await axios.get('https://httpbin.org');
//     console.log(`For request ${requestNumber}, server replied`);
// }

