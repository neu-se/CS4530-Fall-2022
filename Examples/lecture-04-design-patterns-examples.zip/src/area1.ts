type Shape = Square | Circle | ShapeArray

export class Square {
    constructor (public side: number) {}
}

export class Circle {
    constructor (public radius: number) {}
}

// represents ncopies of base shape, arranged in a row
export class ShapeArray {
    constructor (public base: Shape, public ncopies: number) {}
}

export function area (s:Shape) : number {
    if (s instanceof Square) {
        return s.side * s.side
    } else if (s instanceof Circle) {
        return Math.PI * s.radius * s.radius
    } else if (s instanceof ShapeArray) {
        return s.ncopies * area(s.base)
    }
}
