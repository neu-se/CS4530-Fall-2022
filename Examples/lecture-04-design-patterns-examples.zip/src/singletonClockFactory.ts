import IClock from './IClock'
// use whichever clock factory is exported from clockFactories
import ClockFactory from './clockFactories'


export class SingletonClockFactory0  {

    private static theClock : IClock  

    private constructor () {SingletonClockFactory0.theClock = undefined}

    
    public static instance () : IClock {
        if (SingletonClockFactory0.theClock === undefined) {
            SingletonClockFactory0.theClock 
                = (new ClockFactory).instance()
        }
        return SingletonClockFactory0.theClock
    }
}

// the solution above depends on the fact that in TS, 'undefined' is a value.
// here's a solution that doesn't depend on that language property
export default class SingletonClockFactory  {
    private static isInitialized  : boolean
    
    private constructor() {SingletonClockFactory.isInitialized = false} 

    private static theClock : IClock  

    public static instance () : IClock {
        if (!(SingletonClockFactory.isInitialized)) {            
            SingletonClockFactory.theClock
                = (new ClockFactory).instance()
            SingletonClockFactory.isInitialized = true
        }
        return SingletonClockFactory.theClock
    }
}


