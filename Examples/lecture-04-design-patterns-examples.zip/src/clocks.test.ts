import IClock from './IClock'
import * as Clocks from './clocks'

function testClock(clockName: string, c: IClock) {
        c.reset()
        testGetTime(clockName, c, 0)
        c.tick()
        testGetTime(clockName, c, 1)
        c.tick()
        testGetTime(clockName, c, 2)
    }


function testGetTime(
    clockName: string, c: IClock, correctValue: number) {
    const clockTime = c.getTime()
    it(`Testing ${clockName} at ${correctValue}`, () => {
        expect(clockTime).toEqual(correctValue)
    })
}


describe("tests of Clock1", () => { 
    testClock("Clock1", new Clocks.Clock1()) 
})

describe("tests of Clock2", () => {
     testClock("Clock2", new Clocks.Clock2())
})
describe("tests of Clock3", () =>{ 
    testClock("Clock3", new Clocks.Clock3()) 
})



