export interface Shape {
    area() : number
}

export class Square {
    constructor(private side: number) { }
    area() : number { return this.side * this.side }
}


export class Circle {
    constructor (public radius: number) {}
    area() : number { return Math.PI * this.radius * this.radius}
}

// represents ncopies of base shape, arranged in a row
export class ShapeArray {
    constructor (public base: Shape, public ncopies: number) {}
    area() : number {return this.ncopies * this.base.area()}
}

export function area (s:Shape) : number {
    return s.area()
    }

