import IClock from "./IClock";

export class Clock1 implements IClock {
    private time = 0
    public reset () : void {this.time = 0}
    public tick () : void { this.time++ }
    public getTime(): number { return this.time }
}

// counts down from 0
export class Clock2 implements IClock {
    private time = 0
    public reset () : void {this.time = 0}
    public tick () : void { this.time-- }
    public getTime () :number {return (0 - this.time)}
}

// counts from 42
export class Clock3 implements IClock {
    private time = 42
    public reset () : void {this.time = 42}  // I originally put a 0 here :)
    public tick () : void { this.time++ }
    public getTime () : number {return this.time - 42}
}