import IClock from './IClock'
// the raw materials
import * as Clocks from './clocks'


interface AbsClockFactory {
    clockType : string
    instance() : IClock 
    numCreated() : number
}

class ClockFactory1 implements AbsClockFactory {
    clockType = "Clock1"
    numcreated = 0    
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock1}
    public numCreated() : number {return this.numcreated}
}

class ClockFactory2 implements AbsClockFactory {
    clockType = "Clock2"
    numcreated = 0    
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock2}
    public numCreated() : number {return this.numcreated}
}

class ClockFactory3 implements AbsClockFactory {
    clockType = "Clock3"
    numcreated = 0    
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock3}
    public numCreated() {return this.numcreated}
}

// these classes all share some code, so you could make
// an abstract class and have them all inherit from it, 

abstract class ClockFactorySuperClass implements AbsClockFactory {
    abstract clockType: string
    protected numcreated = 0    
    public abstract instance() : IClock 
    public numCreated() {return this.numcreated}
}

class ClockFactory1asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock1" 
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock3}
}
class ClockFactory2asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock3" 
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock3}
}
class ClockFactory3asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock3" 
    public instance() : IClock {
        this.numcreated++;
        return new Clocks.Clock3}
}
// choose which of the factories to export, but don't 
// tell anybody which one it is.
export default ClockFactory1
// export default ClockFactory2
// export default ClockFactory3