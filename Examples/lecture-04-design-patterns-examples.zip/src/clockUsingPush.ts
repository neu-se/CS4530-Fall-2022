

export interface IProducerClock {
    
    reset():void  // resets the time to 0

    /**
     * increments the time and sends a .nofify message with the 
     * current time to all the consumers
     */
    tick():void 
    
    // adds another consumer
    addConsumer(listener:IClockConsumer):void 
}

interface IClockConsumer {
    /**
     *      * @param t - the current time, as reported by the clock
     */
    notify(t:number):void
}

export class ProducerClock implements IProducerClock {
    time = 0
    reset() : void { this.time = 0 } 
    tick() : void { this.time++; this.notifyAll() }     
    
    private observers: IClockConsumer[] = []
    public addConsumer(obs:IClockConsumer): void {
        this.observers.push(obs)
    }
    private notifyAll() : void {
            this.observers.forEach(obs => obs.notify(this.time))
        }
}

export class ObservedClockClient implements IClockConsumer {
    constructor (private theclock:IProducerClock) {
        theclock.addConsumer(this)
    }
    private time = 0  // is this the best way to initialize the time?
    notify (t:number) : void {this.time = t}
    getTime () : number {return this.time}
}

// the Observer gets to decide what to do with the notification
export class DifferentClockClient implements IClockConsumer {
    constructor (private theclock:IProducerClock) {
        theclock.addConsumer(this)
    }
    private time = 0
    private notifications : number[] = [] // just for fun
    notify(t: number) : void { 
        this.notifications.push(t)
        this.time =  t * 2 }
    getTime() : number { return (this.time / 2) }
}





