import IClock from './IClock'
// the raw materials
import * as Clocks from './clocks'


interface AbsClockFactory {
    clockType : string
    instance() : IClock 
    numCreated() : number
}



abstract class ClockFactorySuperClass implements AbsClockFactory {
    abstract clockType: string
    protected abstract buildClock() : IClock
    protected numcreated = 0    
    public instance() : IClock {
        this.numcreated++;
        return this.buildClock()
    }
    public numCreated() {return this.numcreated}
}

class ClockFactory1asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock1" 
    protected buildClock() : IClock {
        return new Clocks.Clock1}
}
class ClockFactory2asSubclass extends ClockFactorySuperClass
 implements AbsClockFactory {
    clockType = "Clock2" 
    protected buildClock() : IClock {
        return new Clocks.Clock2}    
}