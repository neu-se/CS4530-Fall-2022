import axios from 'axios';
import { promises as fsPromises } from 'fs';

function dataFileName(studentID:number):string {
    return `transcript-${studentID}.json`
}

// works on any array of summable things.
function sum(numbers:number[]):number {
    return numbers.reduce((runningTotal, val) => runningTotal + val, 0);
}

type StudentData = {isOK: boolean, id: number, payload?: any }

/** aynchronously retrieves student data,  */
async function asyncGetStudentData(studentID: number): Promise<StudentData> {
    try {
        const returnValue = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
        return { isOK: true, id: studentID, payload: returnValue }
    } catch (e) {
        return { isOK: false, id: studentID }
    }
}

/** asynchronously gets the student data, writes the file,
 * and returns the size of the file
 */
async function asyncProcessStudent(studentID: number): Promise<number> {
    // wait to get the student data
    const response = await asyncGetStudentData(studentID)
    if (!(response.isOK)) {
        console.error(`bad student ID ${studentID}`)
        return 0
    } else {
        await fsPromises.writeFile(
            dataFileName(studentID),
            JSON.stringify(response.payload.data))
        // last, extract its size
        const stats = await fsPromises.stat(dataFileName(studentID))
        const size: number = stats.size
        return size
    }
}
  
async function runClientAsync(studentIDs:number[]) {
    console.log(`Generating Promises for ${studentIDs}`); 
    const studentPromises =  studentIDs.map(studentID => asyncProcessStudent(studentID)) ;  
    console.log('Promises Created! ');
    console.log('Wait for all promises to be satisfied')
    const sizes = await Promise.all(studentPromises);  
    console.log(sizes)        
    const totalSize = sum(sizes)
    console.log(`Finished calculating size: ${totalSize}`);
    console.log('Done');
  }

  // three of these IDs happen to be in the db as of 11/14/22
  // the others are not
  runClientAsync([411,32789,412,423,10202040])

  