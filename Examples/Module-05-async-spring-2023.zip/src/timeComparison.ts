import axios from 'axios';
import { cursorTo } from 'readline';

const debug : boolean = false
const numberOfRequests = 10
const numberOfRuns = 100

async function makeRequest(requestNumber:number) {    
    const response = await axios.get('https://rest-example.covey.town');
    if (debug) {console.log(`request: ${requestNumber} => response: ${response.data}`)}

}

function sum(arr:number[]) : number {return arr.reduce((prev, current) => prev + current, 0)}

async function makeRequestsSerially() {
    for (let i = 1; i <= numberOfRequests; i++) {
        await makeRequest(i)
    }
}

async function makeRequestsConcurrently() {
    let args = []
    for (let i=1; i <= numberOfRequests; i++) { args.push(i) }
    await Promise.all(args.map(arg => makeRequest(arg)))    
}

async function timeIt (thunk: () => any) : Promise<number> {
    const t0 = performance.now();
    await thunk();    
    const t1 = performance.now()
    // console.log((t1-t0).toFixed(2))
    return t1 - t0
}

async function collectRunTimes (thunk: () => any) {
    let totalTime: number = 0
    let numberRun : number = 0
    let minTime =  100000
    let maxTime = 0
    for (let i=1; i <= numberOfRuns; i++) {
        const time = await timeIt(thunk) 
        totalTime = totalTime + time
        numberRun++
        minTime = Math.min(minTime,time);
        maxTime = Math.max(maxTime,time)
    }
    return {min: minTime, max: maxTime, avg: totalTime/numberRun}
}

async function reportRunTimes (label:string, thunk: () => any) {
    const timeStats = await collectRunTimes(thunk);
    const {min,avg,max} = timeStats
    console.log(`${label}: min = ${min.toFixed(0)}  avg = ${avg.toFixed(0)} max = ${max.toFixed(0)} milliseconds`)
}

async function driver() {
    console.log(`After ${numberOfRuns} runs of length ${numberOfRequests}`)
reportRunTimes("makeRequestsSerially    ", makeRequestsSerially)
reportRunTimes("makeRequestsConcurrently", makeRequestsConcurrently)
}

driver()
