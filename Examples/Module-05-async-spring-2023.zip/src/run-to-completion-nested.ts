import axios from 'axios';

async function makeOneGetRequest(requestNumber:string) {
    console.log(`entering makeOneGetRequest`)
    const response = await axios.get('https://rest-example.covey.town')
    console.log(`For request '${requestNumber}', server replied: `, response.data);
}

async function requestWrapper(request:string) {
    console.log('entering wrapper')
    makeOneGetRequest(request)
    console.log('makeOneGetRequest returned')
}

console.log("start of main thread")
console.log(requestWrapper("sample"))
console.log("end of main thread")






