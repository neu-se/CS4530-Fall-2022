import { mock, mockClear } from "jest-mock-extended"
import { nanoid } from "nanoid"
import Player from "../lib/Player"
import { defaultLocation, getLastEmittedEvent } from "../TestUtils"
import { BoundingBox, Interactable, TownEmitter } from "../types/CoveyTownSocket"
import InteractableArea from "./InteractableArea"


type XY = { x: number, y: number };
class TestInteractableArea extends InteractableArea {

    public toModel(): Interactable {
        return { id: this.id, occupantsByID: [] }
    }

}

describe('InteractableArea', () => {
    const testAreaBox = { x: 100, y: 100, width: 100, height: 100 };
    let testArea: InteractableArea;
    const id = nanoid();
    let newPlayer: Player;
    const townEmitter = mock<TownEmitter>();

    beforeEach(() => {
        mockClear(townEmitter);
        testArea = new TestInteractableArea(id, testAreaBox, townEmitter);
        newPlayer = new Player(nanoid(), mock<TownEmitter>());
        testArea.add(newPlayer);
    })
    describe('add', () => {
        it('Adds the player to the occupants list', () => {
            expect(testArea.occupantsByID).toEqual([newPlayer.id]);
        })
        it('Sets the player\'s interactableID and emits an update for their location', () => {
            expect(newPlayer.location.interactableID).toEqual(id);

            const lastEmittedMovement = getLastEmittedEvent(townEmitter, 'playerMoved');
            expect(lastEmittedMovement.location.interactableID).toEqual(id);
        })
    })
    describe('remove', () => {
        it('Removes the player from the list of occupants', () => {
            testArea.remove(newPlayer);
            expect(testArea.occupantsByID).toEqual([]);
        })
        it('Clears the player\'s interactableID and emits an update for their location', () => {
            testArea.remove(newPlayer);
            expect(newPlayer.location.interactableID).toBeUndefined();
            const lastEmittedMovement = getLastEmittedEvent(townEmitter, 'playerMoved');
            expect(lastEmittedMovement.location.interactableID).toBeUndefined();
        })
    })
    describe('contains', () => {
        const { x, y, width, height } = testAreaBox;
        it.each<XY>([
            { x: x + width / 2, y: y + width / 2 }, // at the center
        ])('Returns true for locations that are inside of the area %p', (location: XY) => {
            /* For readability, this test is parameterized over XY points. Each XY point in the array
            passed to "each" above will be used to create a new PlayerLocation (with that center coordinate)
            and then used as a test input to contains
            */
            expect(testArea.contains({ ...defaultLocation(), x: location.x, y: location.y })).toBe(true);
        })
        it.each<XY>([
            { x, y: y - height }, // above 
        ])('Returns false for locations that are outside of the area', (location: XY) => {
            /* For readability, this test is parameterized over XY points. Each XY point in the array
            passed to "each" above will be used to create a new PlayerLocation (with that center coordinate)
            and then used as a test input to contains
            */
            expect(testArea.contains({ ...defaultLocation(), x: location.x, y: location.y })).toBe(false);
        })
    })
    describe('overlaps', () => {
        /*
        To simplify these test inputs, cx and cy refer to the center of the comparison box,
        and height/width are distance from center
        */
        const cheight = testAreaBox.height / 2;
        const cwidth = testAreaBox.width / 2;
        const cx = testAreaBox.x + cwidth;
        const cy = testAreaBox.y + cheight;

        const { x, y, height, width } = testAreaBox;

        it.each<BoundingBox>([
            { x: cx, y: cy, width: 1, height: 1 }, // A bounding box that is entirely contained within the test area
        ])('Returns true for interactables that overlap %p', (intersectBox: BoundingBox) => {
            /* For readability, this test is parameterized over BoundingBoxes. Each bounding box specified
            in the array passed to "each" above will be used to create a new InteractableArea (with that box)
            and then used as a test input to overlaps
            */
            const comparisonArea = new TestInteractableArea('testArea', intersectBox, townEmitter);

            expect(testArea.overlaps(comparisonArea)).toBe(true);
        })
        it.each<BoundingBox>([
            { x: x + width + 100, y: y + height + 100, width: 10, height: 10 }, // Offset to the bottom-right
        ])('Returns false for locations that have no overlap %p', (intersectBox: BoundingBox) => {
            /* For readability, this test is parameterized over BoundingBoxes. Each bounding box specified
            in the array passed to "each" above will be used to create a new InteractableArea (with that box)
            and then used as a test input to overlaps
            */
            const comparisonArea = new TestInteractableArea('testArea', intersectBox, townEmitter);
            expect(testArea.overlaps(comparisonArea)).toBe(false);
        })
    })
})