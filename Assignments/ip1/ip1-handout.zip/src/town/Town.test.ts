import { ITiledMap } from '@jonbell/tiled-map-type-guard';
import { DeepMockProxy, mockDeep, mockReset } from 'jest-mock-extended';
import { nanoid } from 'nanoid';
import Player from '../lib/Player';
import TwilioVideo from '../lib/TwilioVideo';
import { ClientEventTypes, getEventListener, getLastEmittedEvent, MockedPlayer, mockPlayer } from '../TestUtils';
import { ChatMessage, PlayerLocation, TownEmitter } from '../types/CoveyTownSocket';
import Town from './Town';

const mockTwilioVideo = mockDeep<TwilioVideo>();
jest.spyOn(TwilioVideo, 'getInstance').mockReturnValue(mockTwilioVideo);

type TestMapDict = {
  [key in string]: ITiledMap;
}

const TestingMaps: TestMapDict = {
  twoConv: {
    "tiledversion": "1.9.0",
    "tileheight": 32,
    "tilesets": [],
    "tilewidth": 32,
    "type": "map",
    "layers": [
      {
        "id": 4,
        "name": "Objects",
        "objects": [
          {
            "type": "ConversationArea",
            "height": 237,
            "id": 39,
            "name": "Name1",
            "rotation": 0,
            "visible": true,
            "width": 326,
            "x": 40,
            "y": 120
          },
          {
            "type": "ConversationArea",
            "height": 266,
            "id": 43,
            "name": "Name2",
            "rotation": 0,
            "visible": true,
            "width": 467,
            "x": 612,
            "y": 120
          }
        ],
        "opacity": 1,
        "type": "objectgroup",
        "visible": true,
        "x": 0,
        "y": 0
      }]
  }

}

describe('Town', () => {
  const townEmitter: DeepMockProxy<TownEmitter> = mockDeep<TownEmitter>();
  let town: Town;
  let player: Player;
  let playerTestData: MockedPlayer;

  beforeEach(async () => {

    town = new Town(nanoid(), false, nanoid(), townEmitter);
    playerTestData = mockPlayer(town.townID);
    player = await town.addPlayer(playerTestData.userName, playerTestData.socket);
    playerTestData.player = player;
    // Set this dummy player to be off the map so that they do not show up in conversation areas
    playerTestData.moveTo(-1, -1);

    mockReset(townEmitter);
  });


  it('constructor should set its properties', () => {
    const townName = `FriendlyNameTest-${nanoid()}`;
    const townID = nanoid();
    const testTown = new Town(townName, true, townID, townEmitter);
    expect(testTown.friendlyName)
      .toBe(townName);
    expect(testTown.townID).toBe(townID);
    expect(testTown.isPubliclyListed).toBe(true);
  });
  describe('addPlayer', () => {
    it('should use the townID and player ID properties when requesting a video token',
      async () => {
        const newPlayer = mockPlayer(town.townID);
        mockTwilioVideo.getTokenForTown.mockClear();
        const newPlayerObj = await town.addPlayer(newPlayer.userName, newPlayer.socket);

        expect(mockTwilioVideo.getTokenForTown).toBeCalledTimes(1);
        expect(mockTwilioVideo.getTokenForTown).toBeCalledWith(town.townID, newPlayerObj.id);
      });
    it('should register callbacks for all client-to-server events', () => {
      const expectedEvents: ClientEventTypes[] = ['disconnect', 'chatMessage', 'playerMovement'];
      expectedEvents.forEach(eachEvent => expect(getEventListener(playerTestData.socket, eachEvent)).toBeDefined());
    });
  });
  describe('Socket event listeners created in addPlayer', () => {
    describe('on socket disconnect', () => {
      function disconnectPlayer(playerToLeave: MockedPlayer) {
        // Call the disconnect event handler
        const disconnectHandler = getEventListener(playerToLeave.socket, 'disconnect');
        disconnectHandler('unknown');
      }
      it('Invalidates the players\'s session token', async () => {
        const token = player.sessionToken;

        expect(town.getPlayerBySessionToken(token)).toBe(player)
        disconnectPlayer(playerTestData);

        expect(town.getPlayerBySessionToken(token)).toEqual(undefined);
      });
      it('Informs all other players of the disconnection using the broadcast emitter', () => {
        const playerToLeaveID = player.id

        disconnectPlayer(playerTestData);
        const callToDisconnect = getLastEmittedEvent(townEmitter, 'playerDisconnect');
        expect(callToDisconnect.id).toEqual(playerToLeaveID);
      })
    })
    describe('playerMovement', () => {
      const newLocation: PlayerLocation = {
        x: 100,
        y: 100,
        rotation: 'back',
        moving: true
      }

      beforeEach(() => {
        playerTestData.moveTo(newLocation.x, newLocation.y, newLocation.rotation, newLocation.moving);
      })

      it('Emits a playerMoved event', () => {
        const lastEmittedMovement = getLastEmittedEvent(townEmitter, 'playerMoved');
        expect(lastEmittedMovement.id).toEqual(playerTestData.player?.id);
        expect(lastEmittedMovement.location).toEqual(newLocation);
      })
      it('Updates the player\'s location', () => {
        expect(player.location).toEqual(newLocation);
      })
    });
    it('Forwards chat messages to all players in the same town', async () => {
      const chatHandler = getEventListener(playerTestData.socket, 'chatMessage');
      const chatMessage: ChatMessage = {
        author: player.id,
        body: "Test message",
        dateCreated: new Date(),
        sid: 'test message id'
      }

      chatHandler(chatMessage);

      const emittedMessage = getLastEmittedEvent(townEmitter, 'chatMessage');
      expect(emittedMessage).toEqual(chatMessage);

    });
  })
  describe("disconnectAllPlayers", () => {
    beforeEach(() => {
      town.disconnectAllPlayers();
    })
    it('Should emit the townClosing event', () => {
      getLastEmittedEvent(townEmitter, 'townClosing'); // Throws an error if no event existed
    });
    it('Should disconnect each players\'s socket', () => {
      expect(playerTestData.socket.disconnect).toBeCalledWith(true);
    });
  })
  describe('initializeFromMap', () => {
    it('Creates a ConversationArea instance for each region on the map', async () => {
      town.initializeFromMap(TestingMaps.twoConv);
      const conv1 = town.getInteractable('Name1');
      const conv2 = town.getInteractable('Name2');
      expect(conv1.id).toEqual('Name1');
      expect(conv1.boundingBox).toEqual({ x: 40, y: 120, height: 237, width: 326 })
      expect(conv2.id).toEqual('Name2');
      expect(conv2.boundingBox).toEqual({ x: 612, y: 120, height: 266, width: 467 })
      expect(town.interactables.length).toBe(2);
    })
  });
  describe('Updating town settings', () => {
    it('Emits townSettingsUpdated events when friendlyName changes', async () => {
      const newFriendlyName = nanoid();
      town.friendlyName = newFriendlyName;
      expect(townEmitter.emit).toBeCalledWith('townSettingsUpdated', { friendlyName: newFriendlyName });
    });
    it('Emits townSettingsUpdated events when isPubliclyListed changes', async () => {
      const expected = !town.isPubliclyListed;
      town.isPubliclyListed = expected;
      expect(townEmitter.emit).toBeCalledWith('townSettingsUpdated', { isPubliclyListed: expected });
    });
  });
});

